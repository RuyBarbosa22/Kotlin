insert into Musica (nome, data_gravacao, nota_spotify,infantil) values
('5% tint', '2021-08-10', 8.7, false),
('A coolors encore', '2022-11-08', 9.2, false),
('Business', '2023-04-01', 8.5, false),
('pintinho amarelinho', '2007-05-01', 6.7, true),
('A caminho do bega', '2021-06-07', 9.9, true);

insert into cachorro (nome, castrado, peso, motivo_castracao) values
('Pingo', true, 16.7, 'cuidados'),
('Jesse', true, 13.4, 'doenças'),
('Tuco', true, 18.2, 'não quer filhote'),
('Toby', true, 12.8, 'não quer filhote');
