package sptech.projetojpa02

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ProjetoJpa02Application

fun main(args: Array<String>) {
	runApplication<ProjetoJpa02Application>(*args)
}
